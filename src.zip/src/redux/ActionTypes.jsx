export const Set = "SET";

export const Sort_Asc = "Sort_Asc";

export const Sort_Dsc = "Sort_Dsc";

export const Sort_Date_Asc = "Sort_Date_Asc";

export const Sort_Date_Dsc = "Sort_Date_Dsc";

export const Sort_Quality_Asc = "Sort_Quality_Asc";

export const Sort_Quality_Dsc = "Sort_Quality_Dsc";

export const Sort_Explicit = "Sort_Explicit";